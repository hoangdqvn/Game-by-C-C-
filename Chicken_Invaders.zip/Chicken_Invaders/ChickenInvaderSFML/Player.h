#ifndef PLAYER_H
#define PLAYER_H
#include <list>
#include <thread>

#include "Object.h"
#include "Bullet.h"
#include "Map.h"

using namespace std;
using namespace sf;

extern Color hex(Color r, Color g, Color b);

class Player : public chick::Object {
	int bulletInterval;
	int bulletNumber;
	int score;
	Map &map;
	list<Bullet> bullets;
	Texture& bulletTexture;
	Vector lookAt;
public:
	Player(int hp, int damage, double speed, Color color, Map &map, Texture& texture, Texture& bulletTexture)
		: Object(Vector(sizeX / 2, sizeY - 50), Vector(60, 30), hp, damage, speed, color, texture, "player"),
		score(0),
		bulletNumber(1),
		map(map),
		bulletTexture(bulletTexture),
		lookAt(0, 0),
		bulletInterval(500) {}
	list<Bullet>& getBullets() { return bullets; }
	int getBulletInterval() const { return bulletInterval; }
	int getBulletNumber() const { return bulletNumber; }
	int getScore() const { return score; }

	void setScore(int v) { score = v; }
	void changeScore(int v) { score += v; }
	void setBulletInterval(int v) { bulletInterval = v; }
	void setBulletNumber(int v) { bulletNumber = v; }
	void setLookAt(const Vector& v) { 
		lookAt = v.norm(); 
		setRotation(lookAt.getAngle() / 3.14 * 180 + 90);
	}
	void changeBulletInterval(int v) { bulletInterval += v; }
	void changeBulletNumber(int v) { bulletNumber += v; }
	void update() {
		for (Bullet& bullet : bullets) {
			bullet.moveForward();
		}
		Vector next(getCenter() + getDirection() * (getSpeed() * RENDER_INTERVAL / 1000));
		if (next.x <= map.getCenter().x + map.getSize().x 
			&& next.x >= map.getCenter().x - map.getSize().x 
			&& next.y >= 100
			&& next.y <= sizeY - 50
		) {
			setCenter(next);
		}
	}
	void shoot() {
		for (int i = 0; i < bulletNumber; ++i) {
			double dx = (double(i) - double(bulletNumber - 1) / 2) * 40;
			bullets.emplace_back(std::move(Bullet(
				getCenter() + Vector(dx, 0),
				bulletSize, 
				20, 
				getDamage(), 
				2000,
				Color(250, 250, 0),
				bulletTexture
			)));
			bullets.back().setRotation(lookAt.getAngle());
			bullets.back().setDirection(lookAt);
		}
	}
	
	void reset(int hp, int damage, double speed, Color color) {
		bulletNumber = (1);
		bulletInterval = (500);
		setHp(hp);
		setDamage(damage);
		setSpeed(speed);
		setColor(color);
	}
	
};
#endif // !PLAYER_H
