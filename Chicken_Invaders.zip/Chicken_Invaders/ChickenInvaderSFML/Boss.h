#ifndef BOSS_H
#define BOSS_H
#include <list>
#include <thread>

#include "Player.h"
#include "Enemy.h"

using namespace std;
using namespace sf;

extern Color hex(Color r, Color g, Color b);

class Boss : public Enemy {
	int bulletInterval;
	int bulletNumber;
	int score;
	Map &map;
	list<Bullet> bullets;
	Texture& bulletTexture;
	Vector lookAt;
public:
	Boss(Vector center, Vector size, int hp, int damage, double speed, int worth, Color color, Map &map, Texture& texture, Texture& bulletTexture)
		: Enemy(center, size, hp, damage, speed, worth, color, texture),
		score(0),
		bulletNumber(1),
		map(map),
		bulletTexture(bulletTexture),
		lookAt(0, 0),
		bulletInterval(1000) {
			//setDirection(DirectionKey::NONE);
	}

	list<Bullet>& getBullets() { return bullets; }
	int getBulletInterval() const { return bulletInterval; }
	int getBulletNumber() const { return bulletNumber; }
	int getScore() const { return score; }

	void setScore(int v) { score = v; }
	void changeScore(int v) { score += v; }
	void setBulletInterval(int v) { bulletInterval = v; }
	void setBulletNumber(int v) { bulletNumber = v; }
	void setLookAt(const Vector& v) { lookAt = v.norm(); }
	void changeBulletInterval(int v) { bulletInterval += v; }
	void changeBulletNumber(int v) { bulletNumber += v; }
	void update() {
		for (Bullet& bullet : bullets) {
			bullet.moveForward();
		}
		Vector next(getCenter() + getDirection() * (getSpeed() * RENDER_INTERVAL / 1000));
		if (next.x <= map.getCenter().x + map.getSize().x 
			&& next.x >= map.getCenter().x - map.getSize().x) {
				setCenter(next);
		}
	}
	void shoot() {
		for (int i = 0; i < bulletNumber; ++i) {
			double dx = (double(i) - double(bulletNumber - 1) / 2) * 40;
			bullets.emplace_back(std::move(Bullet(
				getCenter() + Vector(dx, 0),
				bulletSize, 
				20, 
				getDamage(), 
				500,
				Color(250, 250, 0),
				bulletTexture
			)));
			bullets.back().setRotation(lookAt.getAngle());
			bullets.back().setDirection(lookAt);
		}
	}
	
};
#endif // !BOSS_H
