#ifndef VECTOR_H
#define VECTOR_H

#include <SFML/Graphics.hpp>

using namespace sf;
class Vector : public Vector2<double> {
public:
	Vector(double x = 0, double y = 0) : Vector2<double>(x, y) {}
	double getX() const { return x; }
	double getY() const { return y; }
	void setXY(double x, double y) {
		this->x = x;
		this->y = y;
	}
	double getAngle() const {
		return atan2(y, x);
	}
	Vector norm() const {
		double len = sqrt(x * x + y * y);
		if (len == 0) len = 0.00001;
		return Vector(x / len, y / len);
	}
	Vector operator+(const Vector& v) const {
		return Vector(x + v.getX(), y + v.getY());
	}
	Vector operator-(const Vector& v) const {
		return Vector(x - v.getX(), y - v.getY());
	}
	Vector operator*(const double k) const {
		return Vector(x * k, y * k);
	}
	bool operator==(const Vector& v) const {
		return x == v.getX() && y == v.getY();
	}
};


#endif // !VECTOR_H
