#ifndef RECTANGLE_H
#define RECTANGLE_H
#include <SFML/Graphics.hpp>
#include <Windows.h>

#include "Vector.h"
#include "Constants.h"

namespace chick {
	using namespace sf;
	class Rectangle : public Sprite {
		Vector center;
		Vector size;
		Color color;
	public:
		Rectangle(Vector center, Vector size, Color color, Texture& texture) : center(center), size(size), color(color), Sprite(texture) {
			texture.setSmooth(1);
			auto textureSize = texture.getSize();
			setOrigin(textureSize.x / 2, textureSize.y / 2);
			setScale(size.x * 2 / textureSize.x, size.y * 2 / textureSize.y);
			move(Vector2f(center));
		}
		Vector getCenter() const { return center; }
		Vector getSize() const { return size; }
		Color getColor() const { return color; }
		void setCenter(Vector v) { 
			center = v;
			setPosition(center.x, center.y);
		}
		void setColor(Color v) { color = v; }
		bool collide(const Rectangle& other) {
			Vector distant = center - other.getCenter();
			Vector sum = size + other.getSize();
			if (abs(distant.x) < abs(sum.x) 
				&& abs(distant.y) < abs(sum.y)) {
				return true;
			}
			return false;
		}
	};
}

#endif // !RECTANGLE_H
