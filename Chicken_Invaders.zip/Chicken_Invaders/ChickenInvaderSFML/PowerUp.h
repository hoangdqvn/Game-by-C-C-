#ifndef POWER_UP_H
#define POWER_UP_H
#include <list>
#include <string>

#include "Object.h"
#include "Player.h"

using namespace std;
using namespace sf;

typedef string(*changePlayerFn)(Player&);
extern minstd_rand0 random;

Vector getRandomSpawnPosition() {
	return Vector(sizeX / 2 - mapSizeX / 2 + random() % mapSizeX, -50);
}

class PowerUp : public chick::Object {
	changePlayerFn fn;
	bool enabled;
public:
	PowerUp(Vector center, Vector size, double speed, Color color, changePlayerFn fn, Texture& texture) : fn(fn),
		enabled(0),
		Object(center, size, 1, 1, speed, color, texture, "power up") {
			setDirection(DirectionKey::NONE);
	}
	void disable() {
		enabled = 0;
		setCenter(outside);
		setDirection(DirectionKey::NONE);
	}
	void enable() {
		if (!enabled) {
			enabled = 1;
			setCenter(getRandomSpawnPosition());
			setDirection(DirectionKey::DOWN);
		}
	}
	string changePlayer(Player& player) {
		return fn(player);
	}
};
#endif // !POWER_UP_H
