#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <list>
#include <vector>
#include <random>
#include <fstream>
#include <Windows.h>


#include "Player.h"
#include "Enemy.h"
#include "PowerUp.h"
#include "Map.h"
#include "Boss.h"

minstd_rand0 random(time(0));

const int RENDER_INTERVAL = 15;

using namespace std;
using namespace sf;

int playerDirection;
GameStage gameStage = GameStage::OPENING;
int baseSpeed = 100;
int baseHp = 100;
int highScore = 0;
RenderWindow window;
Sound shootSound, deadSound;
Text bonusText;

void handleMouseMove(Player& player) {
	Vector2i mouse = Mouse::getPosition(window);
	Vector lookAt = Vector(mouse.x, mouse.y) - player.getCenter();
	player.setLookAt(lookAt);
}

void handleKeyDown(Event::KeyEvent key, Player& player) {
	switch (key.code) {
	case Keyboard::Key::A:
		playerDirection |= DirectionKey::LEFT;
		break;
	case Keyboard::Key::D:
		playerDirection |= DirectionKey::RIGHT;
		break;
	case Keyboard::Key::S:
		playerDirection |= DirectionKey::DOWN;
		break;
	case Keyboard::Key::W:
		playerDirection |= DirectionKey::UP;
		break;
	default:
		break;
	}
}

void handleKeyUp(Event::KeyEvent key, Player& player) {
	switch (key.code) {
	case Keyboard::Key::A:
		playerDirection &= ~DirectionKey::LEFT;
		break;
	case Keyboard::Key::D:
		playerDirection &= ~DirectionKey::RIGHT;
		break;
	case Keyboard::Key::S:
		playerDirection &= ~DirectionKey::DOWN;
		break;
	case Keyboard::Key::W:
		playerDirection &= ~DirectionKey::UP;
		break;
	default:
		break;
	}
}

bool bossDead = 1;

void deleteCollides(Map &map, Player& player, vector<PowerUp>& powerUps, list<Enemy>& enemies, list<Boss>& bosses, Sound& deadSound, Text& bonusText) {
	list<Bullet>& bullets = player.getBullets();
	for (auto& powerUp : powerUps) {
		if (powerUp.collide(player)) {
			bonusText.setString(powerUp.changePlayer(player));
			powerUp.disable();
		}
		if (!powerUp.collide(map)) {
			powerUp.disable();
		}
	}
	for (auto enemyIt = enemies.begin(); enemyIt != enemies.end(); ++enemyIt) {
		if (!enemyIt->collide(map)) {
			deadSound.play();
			enemies.erase(enemyIt);
			return deleteCollides(map, player, powerUps, enemies, bosses, deadSound, bonusText);
		}
		if (enemyIt->collide(player)) {
			player.changeHp(-enemyIt->getDamage());
			player.reset(player.getHp(), 100, 400, Color::Black);
			bonusText.setString("Lost everything");
			deadSound.play();
			enemies.erase(enemyIt);
			if (player.dead()) {
				// game over
				deadSound.play();
				gameStage = GameStage::OVER;
				return;
			} else {
				return deleteCollides(map, player, powerUps, enemies, bosses, deadSound, bonusText);
			}
		} else for (auto bulletIt = bullets.begin(); bulletIt != bullets.end(); ++bulletIt) {
			if (!bulletIt->collide(map)) {
				bullets.erase(bulletIt);
				return deleteCollides(map, player, powerUps, enemies, bosses, deadSound, bonusText);
			}
			if (enemyIt->collide(*bulletIt)) {
				enemyIt->changeHp(-bulletIt->getDamage());

				if (enemyIt->dead()) {
					player.changeScore(enemyIt->getWorth());
					deadSound.play();
					enemies.erase(enemyIt);
				}
				bullets.erase(bulletIt);
				
				return deleteCollides(map, player, powerUps, enemies, bosses, deadSound, bonusText);
			}
		}
	}

	for (auto bulletIt = bullets.begin(); bulletIt != bullets.end(); ++bulletIt) {
		for (auto bossIt = bosses.begin(); bossIt != bosses.end(); ++bossIt) {
			if (bulletIt->collide(*bossIt)) {
				bossIt->changeHp(-bulletIt->getDamage());
				if (bossIt->dead()) {
					player.changeScore(bossIt->getWorth());
					deadSound.play();
					bosses.erase(bossIt);
					bossDead = 1;
				}

				bullets.erase(bulletIt);
				return deleteCollides(map, player, powerUps, enemies, bosses, deadSound, bonusText);
			}
		}
	}
	
	for (auto& boss : bosses) {
		auto& bullets = boss.getBullets();
		for (auto bulletIt = bullets.begin(); bulletIt != bullets.end(); ++bulletIt) {
			if (!bulletIt->collide(map)) {
				bullets.erase(bulletIt);
				return deleteCollides(map, player, powerUps, enemies, bosses, deadSound, bonusText);
			}
			if (bulletIt->collide(player)) {
				player.changeHp(-bulletIt->getDamage());
				player.reset(player.getHp(), 100, 400, Color::Black);
				bonusText.setString("Lost everything");
				bullets.erase(bulletIt);
				if (player.dead()) {
					// game over
					deadSound.play();
					gameStage = GameStage::OVER;
					return;
				} else {
					return deleteCollides(map, player, powerUps, enemies, bosses, deadSound, bonusText);
				}
			}
		}
	}
}

void update(Map &map, Player& player, vector<PowerUp>& powerUps, list<Enemy>& enemies, list<Boss>& bosses) {
	while (1) {
		Sleep(16);
		handleMouseMove(player);
		if (gameStage == GameStage::PLAYING) {
			deleteCollides(map, player, powerUps, enemies, bosses, deadSound, bonusText);
			player.setDirection(DirectionKey::NONE);
			Vector dir(0, 0);
			if (playerDirection & DirectionKey::LEFT) {
				dir = dir + directions[3];
			}
			if (playerDirection & DirectionKey::RIGHT) {
				dir = dir + directions[1];
			}
			if (playerDirection & DirectionKey::UP) {
				dir = dir + directions[4];
			}
			if (playerDirection & DirectionKey::DOWN) {
				dir = dir + directions[2];
			}
			player.setDirection(dir.norm(), 0);
			player.update();
			for (Boss& boss : bosses) {
				boss.update();
			}
			for (Enemy& enemy : enemies) {
				enemy.moveForward();
			}
			for (PowerUp& powerUp : powerUps) {
				powerUp.moveForward();
			}
		}
	}
}

void enemiesChasePlayer(Player& player, list<Enemy>& enemies) {
	while (1) {
		Sleep(50);
		if (gameStage == GameStage::PLAYING) {
			for (Enemy& enemy : enemies) {
				if (enemy.getCenter().y < player.getCenter().y - 50)
					enemy.setDirection((player.getCenter() - enemy.getCenter() + Vector(0, 200)).norm());
			}
		}
	}
}

void autoShoot(Player& player, Sound& sound) {
	while (1) {
		Sleep(player.getBulletInterval());
		if (gameStage == GameStage::PLAYING) {
			sound.play();
			player.shoot();
		}
	}
}

string increaseBulletNumber(Player& player) {
	player.changeBulletNumber(1);
	return "+1 bullet";
}
string decreaseBulletInterval(Player& player) {
	if (player.getBulletInterval() > 100) {
		player.changeBulletInterval(-player.getBulletInterval() / 2);
		return "x2 fire rate";
	}
}
string increaseDamage(Player& player) {
	player.changeDamage(30);
	return "+30 damage";
}
string increaseSpeed(Player& player) {
	player.changeSpeed(100);
	return "+100 speed";
}
string doubleHp(Player& player) {
	player.changeHp(player.getHp() * 2);
	return "x2 HP";
}

changePlayerFn fns[] = {
	increaseBulletNumber,
	decreaseBulletInterval,
	increaseDamage,
	increaseSpeed,
	doubleHp
};

void spawnPowerUps(vector<PowerUp>& powerUps) {
	const int size = powerUps.size();
	while (1) {
		Sleep(2000);
		if (gameStage == GameStage::PLAYING) {
			powerUps[random() % size].enable();
		}
	}
}

void spawnEnemies(list<Enemy>& enemies, Texture& enemyTexture) {
	while (1) {
		Sleep(1000);
		if (gameStage == GameStage::PLAYING) {
			enemies.emplace_back(move(Enemy(
				getRandomSpawnPosition(), 
				Vector(50, 50), 
				baseHp, 
				baseHp / 5,
				baseSpeed / 2 + random() % baseSpeed,
				1,
				Color(250, 10, 10),
				enemyTexture
			)));
		}
	}
}

void spawnBoss(list<Boss>& bosses, Map& map, Texture& bossTexture, Texture& bulletTexture) {
	while (1) {
		if (!bossDead) {
			Sleep(1000);
			continue;
		}
		Sleep(10000);
		if (gameStage == GameStage::PLAYING) {
			bosses.emplace_back(move(Boss(
				getRandomSpawnPosition(), 
				Vector(100, 100), 
				baseHp * 10, 
				99, 
				300, 
				10, 
				Color::Red, 
				map, 
				bossTexture, 
				bulletTexture
			)));
		}
	}
}

void bossAutoShoot(list<Boss>& bosses, Player& player) {
	while (1) {
		if (!bosses.size()) {
			Sleep(100);
			continue;
		}
		Sleep(bosses.back().getBulletInterval());
		if (gameStage == GameStage::PLAYING) {
			for (auto& boss : bosses) {
				boss.setLookAt(player.getCenter() - boss.getCenter());
				boss.shoot();
			}
		}
	}
}

void bossMoveRandomly(list<Boss>& bosses) {
	while (1) {
		Sleep(200 + random() % 500);
		if (gameStage == GameStage::PLAYING) {
			for (auto& boss : bosses) {
				if (boss.getCenter().y >= 50) {
					boss.setDirection((random() % 2) ? DirectionKey::LEFT : DirectionKey::RIGHT);
				}
			}
		}
	}
}

void increaseGameHard() {
	while (1) {
		Sleep(50);
		if (gameStage == GameStage::PLAYING) {
			baseSpeed += 1;
			baseHp += 1;
		}
	}
}

void updateMap(Map& map) {
	int now = 0;
	while (1) {
		Sleep(20);
		if (gameStage == GameStage::PLAYING) {
			now += 20;
			if (now > 1000) {
				map.changeDeltaDy(.2);
				now = 0;
			}
		}
		map.update();
	}
}
/*
void playMp3Long () {
	mciSendString("open \"C:\\SCS\\Group1\\Project1\\Project1\\map.mp3\" type mpegvideo alias mp3", NULL, 0, NULL);
    mciSendString("play mp3 repeat", NULL, 0, NULL);
}
*/
string highSc(Player& player) {
	return "high score: " + to_string(highScore);
}
string score(Player& player) {
	return "score: " + to_string(player.getScore());
}
string hp(Player& player) {
	return "HP: " + to_string(player.getHp());
}
string damage(Player& player) {
	return "damage: " + to_string(player.getDamage());
}
string speed(Player& player) {
	return "speed: " + to_string(player.getSpeed());
}
int main() {
	ifstream highScoreStream("highscore", ios::in);
	if (!highScoreStream.is_open()) highScore = 0;
	else {
		highScoreStream >> highScore;
		highScoreStream.close();
	}

	Font cooperBlack, arcade;
	cooperBlack.loadFromFile("COOPBL.TTF");
	arcade.loadFromFile("ARCADECLASSIC.TTF");

	Music backgroundMusic;
	backgroundMusic.openFromFile("background.ogg");
	backgroundMusic.setLoop(1);
	backgroundMusic.play();

	SoundBuffer shootBuffer, deadBuffer;
	shootBuffer.loadFromFile("laser.ogg");
	deadBuffer.loadFromFile("quack.ogg");

	
	shootSound.setBuffer(shootBuffer);
	deadSound.setBuffer(deadBuffer);

	const Color backgroundColor(30, 30, 30, 255);

	Texture mapTexture, playerTexture, enemyTexture, powerUpTexure, gameOverTextures, emptyTexture, bossTexture;
	mapTexture.loadFromFile("map.jpg");
	playerTexture.loadFromFile("player.png");
	enemyTexture.loadFromFile("enemy2.png");
	powerUpTexure.loadFromFile("power-up2.png");
	gameOverTextures.loadFromFile("gameover.png");
	bossTexture.loadFromFile("enemy.png");

	Sprite gameOverSprite(gameOverTextures);
	gameOverSprite.setScale(sizeX / gameOverTextures.getSize().x, sizeY / gameOverTextures.getSize().y);

	Map map(Vector(mapSizeX / 2, sizeY), Color(), mapTexture);
	Player player(500, 100, 400, Color(), map, playerTexture, playerTexture);
	list<Enemy> enemies;
	list<Boss> bosses;
	vector<PowerUp> powerUps;
	RectangleShape hack(Vector2f(999, sizeY));
	hack.setFillColor(backgroundColor);
	hack.setPosition(sizeX / 2 + mapSizeX / 2 + 50, 0);
	
	Text gameStartTexts[2];
	for (int i = 0; i < 4; ++i) {
		gameStartTexts[i].setFont(arcade);
		gameStartTexts[i].setFillColor(Color::White);
		gameStartTexts[i].setStyle(sf::Text::Bold);
	}
	gameStartTexts[0].setCharacterSize(48);
	gameStartTexts[0].setPosition(400, 600);
	gameStartTexts[0].setString("PRESS  ANY  KEY  TO  START");
	gameStartTexts[1].setCharacterSize(60);
	gameStartTexts[1].setPosition(550, 200);
	gameStartTexts[1].setLineSpacing(1.25);
	gameStartTexts[1].setLetterSpacing(2);
	gameStartTexts[1].setString("CHICKEN\n       NOT\nINVADER");

	Text texts[5];
	for (int i = 0; i < 5; ++i) {
		texts[i] = Text();
		texts[i].setFont(cooperBlack);
		texts[i].setCharacterSize(24);
		texts[i].setFillColor(Color::White);
		texts[i].setStyle(sf::Text::Bold);
		texts[i].setPosition(10, 10 + i * 50);
	}

	bonusText.setFont(cooperBlack);
	bonusText.setCharacterSize(24);
	bonusText.setFillColor(Color(30, 240, 30));
	bonusText.setStyle(sf::Text::Bold);
	bonusText.setPosition(10, 10 + 5 * 50);

	Text instructionText;
	instructionText.setFont(cooperBlack);
	instructionText.setCharacterSize(30);
	instructionText.setFillColor(Color::White);
	instructionText.setStyle(sf::Text::Regular);
	instructionText.setPosition(sizeX / 2 + mapSizeX / 2 + 60, 10);
	instructionText.setString("A: Move left\nD: Move right\nS: Move down\nW: Move up\nMouse: aim\nYou got hit,\nyou lose every\nbonus.\nSo dont get hit!");

	//playMp3Long();
	for (changePlayerFn fn: fns) {
		powerUps.emplace_back(move(PowerUp(
			outside,
			Vector(30, 30), 
			200,
			Color(25, 222, 10),
			fn,
			powerUpTexure
		)));
	}

	window.create(VideoMode(sizeX, sizeY), "Chicken not invaders");
	window.setFramerateLimit(60);
	window.setKeyRepeatEnabled(false);

	thread updateThread(update, ref(map), ref(player), ref(powerUps), ref(enemies), ref(bosses));
	thread increaseGameHardThread(increaseGameHard);
	thread spawnEnemiesThread(spawnEnemies, ref(enemies), ref(enemyTexture));
	thread spawnPowerUpsThread(spawnPowerUps, ref(powerUps));
	thread autoShootThread(autoShoot, ref(player), ref(shootSound));
	thread mapUpdateThread(updateMap, ref(map));
	thread chasePlayerThread(enemiesChasePlayer, ref(player), ref(enemies));
	thread spawnBossThread(spawnBoss, ref(bosses), ref(map), ref(bossTexture), ref(enemyTexture));
	thread bossAutoShootThread(bossAutoShoot, ref(bosses), ref(player));
	thread bossAutoMoveThread(bossMoveRandomly, ref(bosses));
	
	updateThread.detach();
	increaseGameHardThread.detach();
	spawnEnemiesThread.detach();
	spawnPowerUpsThread.detach();
	autoShootThread.detach();
	mapUpdateThread.detach();
	chasePlayerThread.detach();
	spawnBossThread.detach();
	bossAutoShootThread.detach();
	bossAutoMoveThread.detach();

	gameStage = GameStage::OPENING;


	Event event;
    while (window.isOpen())
    {
        // Process events
		if (gameStage == GameStage::OPENING) {
			window.clear(backgroundColor);
			window.draw(map);
			window.draw(gameStartTexts[0]);
			window.draw(gameStartTexts[1]);
			while (window.pollEvent(event)) {
				switch (event.type) {
				case Event::KeyPressed: 
					gameStage = GameStage::PLAYING;
					break;
				case Event::Closed:
					exit(0);
				default:
					break;
				}
			}
			window.draw(hack);
		} else if (gameStage == GameStage::OVER) {
			if (player.getScore() > highScore) {
				highScore = player.getScore();
				ofstream highScoreStream("highscore", ios::out);
				highScoreStream << highScore;
				highScoreStream.close();
			}
			baseSpeed = 100;
			baseHp = 100;
			map = Map(Vector(mapSizeX / 2, 600), Color(), mapTexture);
			player.reset(500, 100, 400, Color());
			player.setScore(0);
			enemies.clear();
			bosses.clear();

			window.draw(gameOverSprite);
			window.draw(gameStartTexts[0]);
			while (window.pollEvent(event)) {
				switch (event.type) {
				case Event::KeyPressed: 
					gameStage = GameStage::OPENING;
					break;
				case Event::Closed:
					exit(0);
				default:
					break;
				}
			}
		} else {
			while (window.pollEvent(event))
			{
				// Close window: exit
				switch (event.type) {
				case Event::KeyPressed: 
					handleKeyDown(event.key, player);
					break;
				case Event::KeyReleased:
					handleKeyUp(event.key, player);
					break;
				case Event::Closed:
					exit(0);
				default:
					break;
				}
			}
			window.clear(backgroundColor);

			window.draw(map);
			for (Enemy& enemy : enemies) {
				window.draw(enemy);
			}
			for (Boss& boss : bosses) {
				window.draw(boss);
				for (Bullet& bullet : boss.getBullets()) {
					window.draw(bullet);
				}
			}
			for (PowerUp& powerUp : powerUps) {
				window.draw(powerUp);
			}
			for (Bullet& bullet : player.getBullets()) {
				window.draw(bullet);
			}

			window.draw(player);
			texts[0].setString(highSc(player));
			texts[1].setString(score(player));
			texts[2].setString(hp(player));
			texts[3].setString(damage(player));
			texts[4].setString(speed(player));
			for (int i = 0; i < 5; ++i) {
				window.draw(texts[i]);
			}
			window.draw(bonusText);
			window.draw(hack);
			window.draw(instructionText);
		}
        window.display();
    }
    return EXIT_SUCCESS;
}