#ifndef BULLET_H
#define BULLET_H

#include "Object.h"

using namespace sf;
class Bullet : public chick::Object {
public:
	Bullet(Vector center, Vector size, int hp, int damage, double speed, Color color, Texture& texture)
		: Object(center, size, hp, damage, speed, color, texture, "bullet") {
			setDirection(DirectionKey::UP);
	}
};

#endif // !BULLET_H
