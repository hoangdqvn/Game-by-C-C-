#ifndef OBJECT_H
#define OBJECT_H
#include <string>

#include "Rectangle.h"

extern const int RENDER_INTERVAL;

namespace chick {
	using namespace std;
	using namespace sf;
	class Object : public chick::Rectangle {
		int hp;
		int damage;
		double speed;
		Vector direction;
		string type;
	public:
		Object(Vector center, Vector size, int hp, int damage, double speed, Color color, Texture& texture, string type) 
			: Rectangle(center, size, color, texture), 
			hp(hp),
			damage(damage),
			speed(speed),
			type(type) {}
		int getHp() { return hp; }
		int getDamage() { return damage; }
		double getSpeed() { return speed; }
		Vector getDirection() { return direction; }
		bool dead() { return hp <= 0; }
		void setDirection(Vector dir, bool lookAt = 1) {
			direction = dir;
			if (lookAt)
				setRotation(dir.getAngle() / 3.14 * 180 - 90);
		}
		void setDirection(DirectionKey dir) {
			switch (dir)
			{
			case NONE:
				direction = directions[0]; 
				break;
			case RIGHT:
				direction = directions[1]; 
				break;
			case DOWN:
				direction = directions[2]; 
				break;
			case LEFT:
				direction = directions[3]; 
				break;
			case UP:
				direction = directions[4]; 
				break;
			default:
				break;
			}
		}
		void setDamage(int v) { damage = v; }
		void setSpeed(int v) { speed = v; }
		void changeDamage(int v) { damage += v; }
		void changeSpeed(int v) { speed += v; }
		void setHp(int v) { hp = v; };
		void changeHp(int v) { 
			hp += v;
		}

		void move(const Vector& v = zero) {
			setCenter(getCenter() + v);
		}
		void moveForward() {
			setCenter(getCenter() + direction * (speed * RENDER_INTERVAL / 1000));
		}
	};
}
#endif // !OBJECT_H
