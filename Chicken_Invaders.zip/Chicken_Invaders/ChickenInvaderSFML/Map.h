#ifndef MAP_H
#define MAP_H
#include <iostream>
#include "Rectangle.h"

using namespace sf;

class Map : public chick::Rectangle {
	double dy;
	double deltaDy;
	int maxDy;
	Vector2i textureRect;
public:
	Map(Vector size, Color color, Texture& texture) : Rectangle(Vector(sizeX / 2, sizeY / 2), size, color, texture), dy(0), maxDy(texture.getSize().y), deltaDy(1) {
		textureRect = Vector2i(texture.getSize());
		setOrigin(textureRect.x / 2, textureRect.y / 2);
		setScale((size.x * 2 + 100) / textureRect.x, (size.y * 2 + 100) / textureRect.y);
		textureRect.x *= getScale().x * 2;
		textureRect.y *= getScale().y * 2;
		texture.setRepeated(1);
	}
	void update() {
		dy = dy - deltaDy;
		if (dy < 0) dy = maxDy - dy;
		setTextureRect(IntRect(Vector2i(0, dy), Vector2i(textureRect)));
	}
	void changeDeltaDy(double v) { deltaDy += v; }
	/*
	void draw() {
		double b = double(getColor() % 256) / 256;
			double g = double((getColor() >> 8) % 256) / 256;
			double r = double((getColor() >> 16) % 256) / 256;
			glColor3d(r, g, b);
			Vector corner1 = zero - getSize() - Vector(100, 100);
			Vector corner2 = getSize() + Vector(100, 100);
			glRectd(corner1.getX(), corner1.getY(), corner2.getX(), corner2.getY());
	}
	*/
};
#endif // !MAP_H
