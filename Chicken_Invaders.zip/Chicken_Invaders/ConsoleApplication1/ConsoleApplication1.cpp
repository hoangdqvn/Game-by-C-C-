// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
int main(int argc, char* argv[])
{ 
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);

	return 0;
}

