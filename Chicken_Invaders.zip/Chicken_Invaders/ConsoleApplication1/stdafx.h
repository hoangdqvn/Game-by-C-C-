// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#include<Windows.h>
// first include Windows.h header file which is required    
#include<stdio.h>    
#include<GL\GL.h>   // GL.h header file    
#include<GL\GLU.h> // GLU.h header file    
#include<GL\glut.h>  // glut.h header file from freeglut\include\GL folder    
#include<conio.h>    
#include<stdio.h>    
#include<math.h>    
#include<string.h>   



// TODO: reference additional headers your program requires here
