#ifndef ENEMY_H
#define ENEMY_H

#include "Object.h"
#include "Bullet.h"

using namespace std;
extern const int RENDER_INTERVAL;

class Enemy : public chick::Object {
	int worth;
public:
	Enemy(Vector center, Vector size, int hp, int damage, double speed, int worth, u_int color)
		: worth(worth),
		Object(center, size, hp, damage, speed, color, "enemy") {
			setDirection(DirectionKey::DOWN);
	}
	int getWorth() { return worth; }
	void draw() const {
		double b = double(getColor() % 256) / 256;
		double g = double((getColor() >> 8) % 256) / 256;
		double r = double((getColor() >> 16) % 256) / 256;
		Vector innerSize = getSize() * .5;
		glPopMatrix();
		glPushMatrix();
		glColor3d(r, g, b);
		glTranslated(getCenter().getX(), getCenter().getY(), 0);
		glutSolidTorus(getSize().getX() * .25, getSize().getX() * .75, 10, 10);
		glPopMatrix();
		glPushMatrix();
	}
};
#endif // !ENEMY_H
