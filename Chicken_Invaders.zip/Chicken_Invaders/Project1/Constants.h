#ifndef CONSTANTS_H
#define CONSTANTS_H

#include "Vector.h"

const double sizeX = 800, sizeY = 600;

enum DirectionKey {
	RIGHT,
	DOWN,
	LEFT,
	UP,
	NONE
};
enum Object {
	Empty,
	WALL,
	APPLE,
	SNAKE
};
enum GameStage {
	OPENING,
	PLAYING,
	OVER
};
enum Mode {
	AUTO,
	MANUAL
};

const Vector directions[] = {
	Vector(1, 0),
	Vector(0, -1),
	Vector(-1, 0),
	Vector(0, 1),
	Vector(0, 0)
};
const Vector zero(0, 0);

const Vector outside(sizeX * 10, sizeY * 10);

const Vector bulletSize(5, 15);

#endif // !CONSTANTS_H
