#ifndef BULLET_H
#define BULLET_H

#include "Object.h"

class Bullet : public chick::Object {
public:
	Bullet(Vector center, Vector size, int hp, int damage, double speed, u_int color)
		: Object(center, size, hp, damage, speed, color, "bullet") {
			setDirection(DirectionKey::UP);
	}
};

#endif // !BULLET_H
