#ifndef POWER_UP_H
#define POWER_UP_H
#include <list>

#include "Object.h"
#include "Player.h"

using namespace std;

typedef void(*changePlayerFn)(Player&);

class PowerUp : public chick::Object {
	changePlayerFn fn;
	bool enabled;
public:
	PowerUp(Vector center, Vector size, double speed, u_int color, changePlayerFn fn) : fn(fn),
		enabled(0),
		Object(center, size, 1, 1, speed, color, "power up") {
			setDirection(DirectionKey::NONE);
	}
	void draw() {
		double b = double(getColor() % 256) / 256;
		double g = double((getColor() >> 8) % 256) / 256;
		double r = double((getColor() >> 16) % 256) / 256;
		glColor3d(r, g, b);
		Vector center = getCenter();
		Vector size = getSize();
		Vector temp;
		glBegin(GL_TRIANGLE_FAN);
			glVertex2d(center.getX(), center.getY());

			temp = center + Vector(0, size.getY());
			glVertex2d(temp.getX(), temp.getY());
			temp = center + Vector(size.getX() * .2, size.getY() * .1);
			glVertex2d(temp.getX(), temp.getY());
			
			glVertex2d(temp.getX(), temp.getY());
			temp = center + Vector(size.getX(), -size.getY());
			glVertex2d(temp.getX(), temp.getY());
			
			glVertex2d(temp.getX(), temp.getY());
			temp = center + Vector(0, -size.getY() * .2);
			glVertex2d(temp.getX(), temp.getY());
			
			glVertex2d(temp.getX(), temp.getY());
			temp = center + Vector(-size.getX(), -size.getY());
			glVertex2d(temp.getX(), temp.getY());
			
			glVertex2d(temp.getX(), temp.getY());
			temp = center + Vector(-size.getX() * .2, size.getY() * .1);
			glVertex2d(temp.getX(), temp.getY());
			
			glVertex2d(temp.getX(), temp.getY());
			temp = center + Vector(0, size.getY());
			glVertex2d(temp.getX(), temp.getY());
			
		glEnd();
	}
	void disable() {
		enabled = 0;
		setCenter(outside);
		setDirection(DirectionKey::NONE);
	}
	void enable() {
		if (!enabled) {
			enabled = 1;
			setCenter(Vector(rand() % 800 - 400, 500));
			setDirection(DirectionKey::DOWN);
		}
	}
	void changePlayer(Player& player) {
		fn(player);
	}
};
#endif // !POWER_UP_H
