#ifndef VECTOR_H
#define VECTOR_H

class Vector {
	double x, y;
public:
	Vector(double x = 0, double y = 0) : x(x), y(y) {}
	double getX() const { return x; }
	double getY() const { return y; }
	void setXY(double x, double y) {
		this->x = x;
		this->y = y;
	}
	Vector operator+(const Vector& v) const {
		return Vector(x + v.getX(), y + v.getY());
	}
	Vector operator-(const Vector& v) const {
		return Vector(x - v.getX(), y - v.getY());
	}
	Vector operator*(const double k) const {
		return Vector(x * k, y * k);
	}
	bool operator==(const Vector& v) const {
		return x == v.getX() && y == v.getY();
	}
};

#endif // !VECTOR_H
