#ifndef MAP_H
#define MAP_H
#include "Rectangle.h"

class Map : public chick::Rectangle {
public:
	Map(Vector size, u_int color) : Rectangle(zero, size, color) {}
	void draw() {
		double b = double(getColor() % 256) / 256;
			double g = double((getColor() >> 8) % 256) / 256;
			double r = double((getColor() >> 16) % 256) / 256;
			glColor3d(r, g, b);
			Vector corner1 = zero - getSize() - Vector(100, 100);
			Vector corner2 = getSize() + Vector(100, 100);
			glRectd(corner1.getX(), corner1.getY(), corner2.getX(), corner2.getY());
	}
};
#endif // !MAP_H
