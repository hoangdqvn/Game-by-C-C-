#include <Windows.h>
#include <iostream>
#include <list>
#include <Vector>
#include <stdio.h>
#include <gl/GL.h> 
#include <gl/GLU.h>
#include <gl/glut.h>
#include <gl/freeglut_ext.h>
#include <conio.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "Player.h"
#include "Enemy.h"
#include "PowerUp.h"
#include "Map.h"

using namespace std;

const int RENDER_INTERVAL = 15;
u_int hex(u_int r, u_int g, u_int b) {
	return (r << 16) + (g << 8) + b;
}

int shouldBeep = 0;
void playBeep() {
	while (1) {
		if (shouldBeep) {
			shouldBeep = 0;
			Beep(200, 500);
		}
	}
}

int windowWidth, windowHeight;
int baseSpeed = 100;
int baseHp = 100;
int choice = 0;
chick::Rectangle chooser(Vector(-150, -270), Vector(20, 20), hex(250, 250, 250));
Map map(Vector(400, 800), hex(15, 15, 15));
Player player(100, 20, baseSpeed * 3, hex(20, 20, 222), map);
list<Enemy> enemies;
vector<PowerUp> powerUps;
GameStage gameStage = GameStage::OPENING;

DirectionKey playerDir = DirectionKey::NONE;

void writeString(const char* text, double x, double y, bool centered = 0) {
	glRasterPos2d(x, y);
	glutBitmapString(GLUT_BITMAP_HELVETICA_18, (u_char*)text);
}

void showIntro() {
	static int height = glutStrokeLength(GLUT_STROKE_MONO_ROMAN, (u_char*)"Chicken");
	static int len1 = glutStrokeLength(GLUT_STROKE_MONO_ROMAN, (u_char*)"Chicken");
	static int len2 = glutStrokeLength(GLUT_STROKE_MONO_ROMAN, (u_char*)"Not invaders!");
	static int len3 = glutStrokeLength(GLUT_STROKE_MONO_ROMAN, (u_char*)"PLAY");
	static int len4 = glutStrokeLength(GLUT_STROKE_MONO_ROMAN, (u_char*)"EXIT");
	chooser.draw();// Vector(-150, -270)
	glLineWidth(20);
	glEnable(GL_LINE_SMOOTH);
	glTranslated(-len1 / 2, height / 4, 0);
	glColor3d(.80, .80, .80);
	glutStrokeString(GLUT_STROKE_MONO_ROMAN, (u_char*)"Chicken");
	glPopMatrix();
	glPushMatrix();
	glTranslated(-len2 / 2, 0, 0);
	glutStrokeString(GLUT_STROKE_MONO_ROMAN, (u_char*)"Not invaders!");
	glPopMatrix();
	glPushMatrix();
	glScaled(.5, .5, 1);
	glTranslated(-len3 / 2, -height * .8, 0);
	glLineWidth(5);
	glEnable(GL_LINE_SMOOTH);
	glColor3d(.15, .80, .80);
	glutStrokeString(GLUT_STROKE_MONO_ROMAN, (u_char*)"PLAY");
	glPopMatrix();
	glPushMatrix();
	glScaled(.5, .5, 1);
	glTranslated(-len4 / 2, -height * 1.15, 0);
	glutStrokeString(GLUT_STROKE_MONO_ROMAN, (u_char*)"EXIT");
}

void showOutro() {
	static int len = glutStrokeLength(GLUT_STROKE_MONO_ROMAN, (u_char*)"Game over!");
	static int len3 = glutStrokeLength(GLUT_STROKE_MONO_ROMAN, (u_char*)"BACK");
	static int height = glutStrokeLength(GLUT_STROKE_MONO_ROMAN, (u_char*)"Chicken");
	static int len4 = glutStrokeLength(GLUT_STROKE_MONO_ROMAN, (u_char*)"EXIT");
	chooser.draw();// Vector(-150, -270)
	glLineWidth(20);
	glEnable(GL_LINE_SMOOTH);
	glTranslated(-len / 2, 0, 0);
	glutStrokeString(GLUT_STROKE_MONO_ROMAN, (u_char*)"Game over!");
	glPopMatrix();
	glPushMatrix();
	glScaled(.5, .5, 1);
	glTranslated(-len3 / 2, -height * .8, 0);
	glLineWidth(5);
	glEnable(GL_LINE_SMOOTH);
	glColor3d(.15, .80, .80);
	glutStrokeString(GLUT_STROKE_MONO_ROMAN, (u_char*)"BACK");
	glPopMatrix();
	glPushMatrix();
	glScaled(.5, .5, 1);
	glTranslated(-len4 / 2, -height * 1.15, 0);
	glutStrokeString(GLUT_STROKE_MONO_ROMAN, (u_char*)"EXIT");
}

// Init_OpenGL() function
void Init_OpenGL()
{
    // set map color to Black
    glClearColor(.15, .15, .15, 0.0);
    // set shade model to Flat
    glShadeModel(GL_FLAT);
}
    
// Display_Objects() function
void Display_Objects(void)
{
    // clearing the window or remove all drawn objects
    glClear(GL_COLOR_BUFFER_BIT);
    /*glPushMatrix(), which copies the current matrix and adds  
    the copy to the top of the stack, and  
    glPopMatrix(), which discards the top matrix on the stack*/
    glPushMatrix();
    //the glTranslatef() routine in the display list alters the position of the next object to be drawn
    glTranslatef(0.0, 0.0, 0.0);
    // set color to object glColor3f(red,green,blue);
    //glColor3f(1.0, 0.8, 0.0);
	
	if (gameStage == GameStage::OPENING) {
		showIntro();
	} else if (gameStage == GameStage::OVER) {
		showOutro();
	} else {

		map.draw();
		for (const Enemy& enemy : enemies) {
			enemy.draw();
		}
		for (PowerUp& powerUp : powerUps) {
			powerUp.draw();
		}
		for (const Bullet& bullet : player.getBullets()) {
			bullet.draw();
		}
		player.draw();
		glColor3d(.8, .8, .8);
		string status = "Score: " + to_string(player.getScore());
		writeString(status.c_str(), -windowWidth + 10, windowHeight - 70);
		status = "HP: " + to_string(player.getHp());
		writeString(status.c_str(), -windowWidth + 10, windowHeight - 120);
		status = "Damage: " + to_string(player.getDamage());
		writeString(status.c_str(), -windowWidth + 10, windowHeight - 170);
		status = "Speed: " + to_string(player.getSpeed());
		writeString(status.c_str(), -windowWidth + 10, windowHeight - 220);
	}
	
    //drawImage(texture, 0.0f, 0.0f, 400.0f, 400.0f, 0.0);
	
    glPopMatrix();
    glutSwapBuffers();
}
// Reshape() function
void Reshape(int w, int h)
{
	windowWidth = w;
	windowHeight = h;
    //adjusts the pixel rectangle for drawing to be the entire new window
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    //matrix specifies the projection transformation
    glMatrixMode(GL_PROJECTION);
    // load the identity of matrix by clearing it.
    glLoadIdentity();
    //gluPerspective(60.0, (GLfloat)w / (GLfloat)h, 1.0, 20.0);
	glOrtho(-w, w, -h, h, -1000, 1000);
	//glOrtho(-1000, 1000, -1000, 1000, -1, 1);
    //matrix specifies the modelview transformation
    glMatrixMode(GL_MODELVIEW);
    // again  load the identity of matrix
    glLoadIdentity();
    // gluLookAt() this function is used to specify the eye.
    // it is used to specify the coordinates to view objects from a specific position
    //gluLookAt(-0.3, 0.5, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}

void stopMove(int value) {
	playerDir = DirectionKey::NONE;
}

void onKey(unsigned char key, int x, int y) {
	if (key == 13) {
		if (choice == 1) {
			exit(0);
		} else {
			if (gameStage == GameStage::OPENING) {
				gameStage = GameStage::PLAYING;
				baseSpeed = 100;
				baseHp = 100;
				choice = 0;
				player.reset(100, 20, baseSpeed * 3, hex(20, 20, 222));
				enemies.clear();
			} else if (gameStage == GameStage::OVER) {
				gameStage = GameStage::OPENING;
			}
		}
	} else if (key == 'a') playerDir = DirectionKey::LEFT;
	else if (key == 'd') playerDir = DirectionKey::RIGHT;
	else playerDir = DirectionKey::NONE;
}

void onArrowKey(int key, int x, int y) {
	if (key == GLUT_KEY_UP) {
		choice = 0;
		chooser.setCenter(Vector(-150, -270));
	} else if (key == GLUT_KEY_DOWN) {
		choice = 1;
		chooser.setCenter(Vector(-150, -400));
	} 
}

void autoShoot(int value) {
	if (gameStage == GameStage::PLAYING) {
		player.shoot();
	}
	glutTimerFunc(player.getBulletInterval(), autoShoot, 0);
}

void deleteCollides() {
	list<Bullet>& bullets = player.getBullets();
	for (auto& powerUp : powerUps) {
		if (powerUp.collide(player)) {
			powerUp.changePlayer(player);
			powerUp.disable();
			return deleteCollides();
		}
	}
	for (auto enemyIt = enemies.begin(); enemyIt != enemies.end(); ++enemyIt) {
		if (!enemyIt->collide(map)) {
			enemies.erase(enemyIt);
			return deleteCollides();
		}
		if (enemyIt->collide(player)) {
			player.changeHp(-enemyIt->getDamage());
			enemies.erase(enemyIt);
			if (player.dead()) {
				// game over
				gameStage = GameStage::OVER;
				return;
			} else {
				return deleteCollides();
			}
		} else for (auto bulletIt = bullets.begin(); bulletIt != bullets.end(); ++bulletIt) {
			if (!bulletIt->collide(map)) {
				bullets.erase(bulletIt);
				return deleteCollides();
			}
			if (enemyIt->collide(*bulletIt)) {
				enemyIt->changeHp(-bulletIt->getDamage());

				if (enemyIt->dead()) {
					player.changeScore(enemyIt->getWorth());
					enemies.erase(enemyIt);
				}
				bullets.erase(bulletIt);

				return deleteCollides();
			}
		}
	}
}

void increaseBulletNumber(Player& player) {
	player.changeBulletNumber(1);
}
void decreaseBulletInterval(Player& player) {
	player.changeBulletInterval(-player.getBulletInterval() / 2);
}
void increaseDamage(Player& player) {
	player.changeDamage(30);
}
void increaseSpeed(Player& player) {
	player.changeSpeed(300);
}

changePlayerFn fns[] = {
	increaseBulletNumber,
	decreaseBulletInterval,
	increaseDamage,
	increaseSpeed
};

void spawnPowerUps(int value) {
	if (gameStage == GameStage::PLAYING) {
		powerUps[rand() % 4].enable();
	}
	glutTimerFunc(5000, spawnPowerUps, 0);
}

void updateLoop(int value) {
	if (gameStage == GameStage::PLAYING) {
		deleteCollides();
		player.setDirection(playerDir);
		player.update();
		for (Enemy& enemy : enemies) {
			enemy.moveForward();
		}
		for (PowerUp& powerUp : powerUps) {
			powerUp.moveForward();
		}
		glutPostRedisplay();
	}
	glutTimerFunc(RENDER_INTERVAL, updateLoop, 0);
}

void spawnEnemies(int value) {
	if (gameStage == GameStage::PLAYING) {
		enemies.emplace_back(move(Enemy(
			Vector(double(rand()) / RAND_MAX * 1000 - 500, 500), 
			Vector(50, 50), 
			baseHp, 
			baseHp / 5,
			baseSpeed,
			1,
			hex(250, 10, 10)
		)));
	}
	glutTimerFunc(1000, spawnEnemies, 0);
}

void increaseGameSpeed(int value) {
	if (gameStage == GameStage::PLAYING) {
		baseSpeed += 1;
	}
	glutTimerFunc(50, increaseGameSpeed, 0);
}

void increaseEnemyHp(int value) {
	if (gameStage == GameStage::PLAYING) {
		baseHp += 1;
	}
	glutTimerFunc(500, increaseEnemyHp, 0);
}

void playMp3Long () {
	mciSendString("open \"C:\\SCS\\Group1\\Project1\\Project1\\map.mp3\" type mpegvideo alias mp3", NULL, 0, NULL);
    mciSendString("play mp3 repeat", NULL, 0, NULL);
}

// main function
int main(int argc, char** argv)
{
	playMp3Long();
	for (changePlayerFn fn: fns) {
		powerUps.emplace_back(move(PowerUp(
			outside, 
			Vector(50, 50), 
			200,
			hex(25, 222, 10),
			fn
		)));
	}
    // initialize glut
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    // set window size
    glutInitWindowSize(800, 600);
    // set window location
    glutInitWindowPosition(250, 50);
    // create window with window text
    glutCreateWindow("Chicken not invaders");
    // call Init_OpenGL() function
    Init_OpenGL();
    // call glutDisplayFunc() function & pass parameter as Display_Objects() function
    glutDisplayFunc(Display_Objects);
    // call glutReshapeFunc() function & pass parameter as Reshape() function
    glutReshapeFunc(Reshape);
	glutKeyboardFunc(onKey);
	glutSpecialFunc(onArrowKey);

	glutTimerFunc(RENDER_INTERVAL, updateLoop, 0);
	glutTimerFunc(RENDER_INTERVAL, autoShoot, 0);
	glutTimerFunc(RENDER_INTERVAL, spawnEnemies, 0);
	glutTimerFunc(RENDER_INTERVAL, increaseGameSpeed, 0);
	glutTimerFunc(RENDER_INTERVAL, spawnPowerUps, 0);
	glutTimerFunc(RENDER_INTERVAL, increaseEnemyHp, 0);
    //glutMainLoop() is used to redisplay the objects
    glutMainLoop();
    return 0;
}