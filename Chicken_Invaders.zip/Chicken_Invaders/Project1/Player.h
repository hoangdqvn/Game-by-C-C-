#ifndef PLAYER_H
#define PLAYER_H
#include <list>
#include <thread>

#include "Object.h"
#include "Bullet.h"
#include "Map.h"

using namespace std;

extern u_int hex(u_int r, u_int g, u_int b);

extern int shouldBeep;
extern void playBeep();

class Player : public chick::Object {
	int bulletInterval;
	int bulletNumber;
	int score;
	Map &map;
	list<Bullet> bullets;
	thread sound;
public:
	Player(int hp, int damage, double speed, u_int color, Map &map)
		: Object(Vector(0, -500), Vector(60, 30), hp, damage, speed, color, "player"), 
		score(0),
		bulletNumber(1),
		map(map),
		bulletInterval(500) {
			sound = thread(playBeep);
	}
	list<Bullet>& getBullets() { return bullets; }
	int getBulletInterval() const { return bulletInterval; }
	int getBulletNumber() const { return bulletNumber; }
	int getScore() const { return score; }

	void setScore(int v) { score = v; }
	void changeScore(int v) { score += v; }
	void setBulletInterval(int v) { bulletInterval = v; }
	void setBulletNumber(int v) { bulletNumber = v; }
	void changeBulletInterval(int v) { bulletInterval += v; }
	void changeBulletNumber(int v) { bulletNumber += v; }
	
	void draw() {
		double b = double(getColor() % 256) / 256;
		double g = double((getColor() >> 8) % 256) / 256;
		double r = double((getColor() >> 16) % 256) / 256;
		glColor3d(r, g, b);
		Vector center = getCenter();
		Vector size = getSize();
		Vector temp;
		glBegin(GL_TRIANGLE_FAN);
			temp = center + Vector(0, size.getY());
			glVertex2d(temp.getX(), temp.getY());
			temp = center + Vector(size.getX(), -size.getY());
			glVertex2d(temp.getX(), temp.getY());
			temp = center + Vector(0, -size.getY() / 2);
			glVertex2d(temp.getX(), temp.getY());
			temp = center + Vector(-size.getX(), -size.getY());
			glVertex2d(temp.getX(), temp.getY());
		glEnd();
	}
	void update() {
		for (Bullet& bullet : bullets) {
			bullet.moveForward();
		}
		Vector next(getCenter() + getDirection() * (getSpeed() * RENDER_INTERVAL / 1000));
		if (next.getX() <= map.getSize().getX() && next.getX() >= -map.getSize().getX()) {
			setCenter(next);
		}
	}
	void shoot() {
		shouldBeep = 1;
		for (int i = 0; i < bulletNumber; ++i) {
			double dx = (double(i) - double(bulletNumber - 1) / 2) * 40;
			bullets.emplace_back(std::move(Bullet(
				getCenter() + Vector(dx, 0),
				bulletSize, 
				20, 
				getDamage(), 
				2000, 
				hex(250, 250, 0)
			)));
		}
	}
	
	void reset(int hp, int damage, double speed, u_int color) {
		setHp(hp);
		setDamage(damage);
		setSpeed(speed);
		setColor(color);
	}
	
};
#endif // !PLAYER_H
