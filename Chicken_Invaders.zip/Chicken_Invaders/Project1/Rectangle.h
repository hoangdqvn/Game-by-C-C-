#ifndef RECTANGLE_H
#define RECTANGLE_H
#include <Windows.h>
#include <iostream>
#include <gl/GL.h>   // GL.h header file    
#include <gl/GLU.h> // GLU.h header file    
#include <gl/glut.h>  // glut.h header file from freeglut\include\GL folder    

#include "Vector.h"
#include "Constants.h"

namespace chick {
	class Rectangle {
		Vector center;
		Vector size;
		u_int color;
	public:
		Rectangle(Vector center, Vector size, u_int color) : center(center), size(size), color(color) {}
		Vector getCenter() const { return center; }
		Vector getSize() const { return size; }
		u_int getColor() const { return color; }
		void setCenter(Vector v) { center = v; }
		void setColor(u_int v) { color = v; }
		virtual void draw(/* maybe some openGL var here */) const {
			// TODO: implement this, and implement in the derived classes as well.
			// here is the ugliest one
			double b = double(color % 256) / 256;
			double g = double((color >> 8) % 256) / 256;
			double r = double((color >> 16) % 256) / 256;
			glColor3d(r, g, b);
			Vector corner1 = center - size;
			Vector corner2 = center + size;
			glRectd(corner1.getX(), corner1.getY(), corner2.getX(), corner2.getY());
		}
		bool collide(const Rectangle& other) {
			Vector distant = center - other.getCenter();
			Vector sum = size + other.getSize();
			if (abs(distant.getX()) < abs(sum.getX()) 
				&& abs(distant.getY()) < abs(sum.getY())) {
				return true;
			}
			return false;
		}
	};
}

#endif // !RECTANGLE_H
